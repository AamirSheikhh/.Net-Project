﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeManagementSystem.Models.Employee_Models
{
    public class EmployeeClass
    {
        [Key]
            public int EmployeeId { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
            public string Position { get; set; }
            public DateTime DateOfJoining { get; set; }
 

    }
}
