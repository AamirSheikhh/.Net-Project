﻿
using EmployeeManagementSystem.Models.Employee_Models;
using Microsoft.EntityFrameworkCore;

public class EmployeeDbContext : DbContext
{
    public EmployeeDbContext(DbContextOptions<EmployeeDbContext> options) : base(options) { }

    public DbSet<EmployeeClass> Employees { get; set; }
}
